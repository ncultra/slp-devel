#define LSLP_CHANGESET "150:3f755a7b54ba"
#define LSLP_TAG "tip"
