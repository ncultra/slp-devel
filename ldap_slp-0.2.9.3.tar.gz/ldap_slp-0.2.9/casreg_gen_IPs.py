#! /usr/bin/env python

# ibmslp.conf generator for multiple CAS agents in registry
# Author: Kyung Ryu

import sys
import os

cas_num = int(sys.argv[1])          	# number of CAS agents to generate
cas_start = int(sys.argv[2])
cas_lifetime = sys.argv[3]		

cas_domain = '10.10.3'  # ip domain

# generate slp_regsrv command and execute
cas_header = 'slp_srvreg --type=service:management-software.IBM:usma --url=service:management-software.IBM:usmb://'
cas_mac = '000D6015326E'
cas_address = '127.0.0.1'
cas_version = '1.4.0.0'
cas_manager = 'unmanaged'

for x in range(0, cas_num):
    cas_no = cas_start + x
    #cas_addrspec = 'FakeCAS'+str(cas_no)
    cas_ipaddr = cas_domain + '.' + str(cas_no+10)
    cas_addrspec = cas_ipaddr;
    cas_port = `9700 + 10*cas_no`
    cas_uuid = `10103209720 + cas_no`
    cas_uid = '6EF84264A8E811DC9F7D00145E5DC'+ `100 + cas_no`
    cas_command = cas_header + cas_addrspec + ' --attributes="(uid=' + cas_uid + '),(ip-address=' + cas_ipaddr + '),(port=' + cas_port + '),(version=' + cas_version + '),(manager=' + cas_manager + '),(uuid=' + cas_uuid + '),(mac-address=' + cas_mac + ')" --lifetime=' + cas_lifetime + ' --address=' + cas_address
    print cas_command
    os.system(cas_command)

#os.system('./slp_query --type=service:management-software.IBM:usma | grep FakeCAS')
os.system('slp_query --type=service:management-software.IBM:usma --address=192.168.2.103 | grep usma')

